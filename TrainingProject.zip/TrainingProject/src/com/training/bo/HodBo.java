package com.training.bo;

import com.training.bean.Leave;
import com.training.bean.Meeting;
import com.training.dao.HodDao;
import com.training.dao.HodDaoImpl;

public class HodBo {
	public void create(Meeting meet) {
		HodDao hodDao=new HodDaoImpl();
		hodDao.create(meet);
		
	}

	public void create(Leave l) {
		// TODO Auto-generated method stub
		HodDao hodDao=new HodDaoImpl();
		hodDao.create(l);
		
	}

}
