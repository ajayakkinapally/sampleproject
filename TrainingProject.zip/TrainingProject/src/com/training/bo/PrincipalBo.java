package com.training.bo;

import com.training.bean.AddFaculty;
import com.training.bean.Meeting;
import com.training.dao.PrincipalDao;
import com.training.dao.PrinicipalDaoImpl;


public class PrincipalBo {

		public static void create(AddFaculty addfac) throws ClassNotFoundException {
			PrincipalDao principalDao=new PrinicipalDaoImpl();
			principalDao.create(addfac);
			
		}
		public static void create(Meeting meet) {
			PrincipalDao principalDao=new PrinicipalDaoImpl();
			principalDao.create(meet);
			
		}
		
		public void delete(String empid) throws ClassNotFoundException {
			// TODO Auto-generated method stub
			PrincipalDao principalDao=new PrinicipalDaoImpl();
			principalDao.delete(empid);
			
		}
		public void paperapprov(String p_id,String status) throws ClassNotFoundException {
			// TODO Auto-generated method stub
			PrincipalDao principalDao=new PrinicipalDaoImpl();
			 principalDao.paperapprov(p_id,status);
			
			
		}
		public void leaveapprov(String empid, String status) throws ClassNotFoundException {
			// TODO Auto-generated method stub
			PrincipalDao principalDao=new PrinicipalDaoImpl();
			 principalDao.leaveapprov(empid,status);
			
		}
		
}
