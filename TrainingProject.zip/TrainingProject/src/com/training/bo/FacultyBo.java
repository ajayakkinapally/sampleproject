package com.training.bo;

import com.training.bean.Meeting;
import com.training.bean.UploadPaper;
import com.training.dao.FacultyDao;
import com.training.dao.FacultyDaoImpl;


public class FacultyBo {
	public void create(Meeting meet) {
	FacultyDao facultyDao=new FacultyDaoImpl();
	facultyDao.create(meet);
	
     }

	public void create(UploadPaper up) {
		FacultyDao facultyDao=new FacultyDaoImpl();
		facultyDao.create(up);
		
	}

	

}
