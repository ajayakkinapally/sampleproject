package com.training.view;


import java.util.Scanner;

import com.training.bean.AddFaculty;
import com.training.bean.Leave;
import com.training.bean.Meeting;
import com.training.bean.UploadPaper;
import com.training.bo.FacultyBo;
import com.training.bo.HodBo;
import com.training.bo.PrincipalBo;

public class PreparedStDemo {
	public static void main(String[] args) throws ClassNotFoundException {


		Scanner scanner = new Scanner(System.in);
		int contact,m_id;
		String fname,lname,mail,choice,m_date,start_date,end_date,status;
		int ch;
		String p_id,empid;
		String subject;
		String branch;
		PrincipalBo principalBo = new PrincipalBo();
		HodBo hodBo=new HodBo();
		FacultyBo facBo=new FacultyBo();
		do {
			
			   System.out.println("Welcome to Home Page");
		       System.out.println("1.Principal \n 2.HOD \n 3.Faculty");
		       System.out.println("Enter choice");
		       ch = scanner.nextInt();
		 
			   switch (ch) {
			
			   		case 1:
		
			   				do {
			   						System.out.println("Welcome to Principle Page");
			   						System.out.println("1.Add Faculty \n 2.Meeting \n 3.Managing details \n 4.Paper Approval \n 5.leave approval");
			   						System.out.println("Enter choice");
			   						ch = scanner.nextInt();
			   						switch (ch) {
			   								case 1:
			   										System.out.println("Enter  faculty details to add empid,fname,lname,mail,contact");
			   										empid = scanner.next();
			   										fname = scanner.next();
			   										lname=scanner.next();
			   										mail = scanner.next();
			   										contact = scanner.nextInt();
				
			   										AddFaculty a = new AddFaculty();
			   										a.setempid(empid);
			   										a.setfName(fname);
			   										a.setlName(lname);
			   										a.setmail(mail);
			   										a.setcontact(contact);
			   										PrincipalBo.create(a);
			   										break;
					      
			   								case 2:
			   									System.out.println("Enter  meeting details to create meeting m_id,m_date,empid");
		   										m_id = scanner.nextInt();
		   										m_date = scanner.next();
		   										empid = scanner.next();
			
		   										Meeting m = new Meeting();
		   										m.setm_id(m_id);
		   										m.setm_date(m_date);
		   										m.setempid(empid);
		   										PrincipalBo.create(m);
		   										break;
			   								case 3:
			   										System.out.println("Enter empid to delete");
			   										empid = scanner.next();
			   										principalBo.delete(empid);
			   										break;	
			   								case 4:
			   									System.out.println("Enter  pid and status for paper approval");
		   										p_id = scanner.next();
		   										status=scanner.next();
		   										principalBo.paperapprov(p_id,status);
		   										break;	
			   								case 5:
			   									System.out.println("Enter empid and status for leave approval");
		   										empid = scanner.next();
		   										status=scanner.next();
		   										principalBo.leaveapprov(empid,status);
		   										break;	
			   									
			   								default:
			   										System.out.println("Invalid choice");
			   						}
				   
			   						System.out.println("want to continue principal page");
			   						choice = scanner.next();
			   						} while(choice.equals("yes"));
			   						break;
			   		case 2:
			   			do {
	   								System.out.println("Welcome to HOD Page");
	   								System.out.println("1.Meeting \n 2.leaves \n");
	   								System.out.println("Enter choice");
	   								ch = scanner.nextInt();
	   								switch (ch) {
	   										case 1:
	   											System.out.println("Enter  meeting details to create meeting m_id,m_date,empid");
		   										m_id = scanner.nextInt();
		   										m_date = scanner.next();
		   										empid = scanner.next();
			
		   										Meeting m = new Meeting();
		   										m.setm_id(m_id);
		   										m.setm_date(m_date);
		   										m.setempid(empid);
		   										hodBo.create(m);
		   										break;
	   										case 2:
	   											System.out.println("enter details for apply leave start_dat,end_date,empid");
		   										start_date = scanner.next();
		   										end_date = scanner.next();
		   										empid = scanner.next();
		   										//status=scanner.hasNextInt();
			
		   										Leave l = new Leave();
		   										l.setstart_date(start_date);
		   										l.setend_date(end_date);
		   										l.setempid(empid);
		   										//l.setstatus(status);
		   										hodBo.create(l);
		   										break;
	   										default:
	   												System.out.println("Invalid choice");
	   								}
	   								System.out.println("want to continue HOD page");
	   								choice = scanner.next();
   						} while(choice.equals("yes"));
   						break;
   						 
			   		case 3:
			   				do {
	   								System.out.println("Welcome to Faculty Page");
	   								System.out.println("1.Meeting \n 2.Upload Paper \n");
	   								System.out.println("Enter choice");
	   								ch = scanner.nextInt();
	   								
									switch (ch) {
	   										case 1:
	   											   
	   											System.out.println("Enter  meeting details to create meeting m_id,m_date,empid");
		   										m_id = scanner.nextInt();
		   										m_date = scanner.next();
		   										empid = scanner.next();
			
		   										Meeting m = new Meeting();
		   										m.setm_id(m_id);
		   										m.setm_date(m_date);
		   										m.setempid(empid);
		   										facBo.create(m);
	   											break;
	   										case 2:
	   											System.out.println("Enter  paper details to upload p_id,subject,empid,branch");
		   										p_id = scanner.next();
		   										subject = scanner.next();
		   										empid = scanner.next();
		   										//status=scanner.next();
			                                    branch=scanner.next();
		   										UploadPaper up = new UploadPaper();
		   										up.setp_id(p_id);
		   										up.setsubject(subject);
		   										up.setempid(empid);
		   										up.setbranch(branch);
		   										facBo.create(up);
	   												break;
	   										default:
	   												System.out.println("Invalid choice");
	   								}
	   								System.out.println("want to continue Faculty page");
	   								choice = scanner.next();
			   				} while(choice.equals("yes"));
			   				break;	
			   		default:
							System.out.println("Invalid choice");
			     	}
			   		System.out.println("want to continue home page");
			   		choice = scanner.next();
					} while(choice.equals("yes"));
		
			   }
	}
