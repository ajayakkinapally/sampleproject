package com.training.dao;

import com.training.bean.AddFaculty;
import com.training.bean.Meeting;
import com.training.bean.Leave;

public interface PrincipalDao {
	public void create(AddFaculty addfaculty) throws ClassNotFoundException;
	public void create(Meeting m);
	//public void create(ManageDetails manage);
	public void delete(String empid) throws ClassNotFoundException;
	void paperapprov(String p_id, String status) throws ClassNotFoundException;
	void leaveapprov(String empid, String status) throws ClassNotFoundException;
}
