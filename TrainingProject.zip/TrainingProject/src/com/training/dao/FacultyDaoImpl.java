package com.training.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.training.bean.Meeting;
import com.training.bean.UploadPaper;

public class FacultyDaoImpl implements FacultyDao{
	private String getstatus;

	public void create(Meeting m) {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/orcl","scott","tiger");
			// conn.setAutoCommit(false);
			String query = "insert into meet(m_id,m_date,empid) values(?,?,?)";
			ps = conn.prepareStatement(query);
			ps.setInt(1,m.getm_id());
			ps.setString(2, m.getm_date());
			ps.setString(3, m.getempid());
			
			int rows = ps.executeUpdate();
			System.out.println(rows + "row  inserted");
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
	}

	@Override
	public void create(UploadPaper up) {
		// TODO Auto-generated method stub
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/orcl","scott","tiger");
			// conn.setAutoCommit(false);
			String query = "insert into paper(p_id,subject,empid,status,branch) values(?,?,?,?,?)";
			ps = conn.prepareStatement(query);
			ps.setString(1,up.getp_id());
			ps.setString(2, up.getsubject());
			ps.setString(3, up.getempid());
			ps.setString(4,up.getstatus());
			ps.setString(5,up.getbranch());
			
			int rows = ps.executeUpdate();
			System.out.println(rows + "row  inserted");
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		
	}

	

}
