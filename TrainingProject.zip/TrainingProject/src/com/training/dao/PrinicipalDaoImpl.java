package com.training.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.training.bean.AddFaculty;
import com.training.bean.Meeting;



public class PrinicipalDaoImpl implements PrincipalDao {

	public void create(AddFaculty a) {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/orcl","scott","tiger");
			// conn.setAutoCommit(false);
			String query = "insert into add_faculty(empid,fname,lname,mail,contact) values(?,?,?,?,?)";
			ps = conn.prepareStatement(query);
			ps.setString(1,a.getempid());
			ps.setString(2, a.getfName());
			ps.setString(3, a.getlName());
			ps.setString(4, a.getmail());
			ps.setInt(5, a.getcontact());
			
			int rows = ps.executeUpdate();
			System.out.println(rows + "row  inserted");
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
	}
	public void create(Meeting m) {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/orcl","scott","tiger");
			// conn.setAutoCommit(false);
			String query = "insert into meet(m_id,m_date,empid) values(?,?,?)";
			ps = conn.prepareStatement(query);
			ps.setInt(1,m.getm_id());
			ps.setString(2, m.getm_date());
			ps.setString(3, m.getempid());
			
			int rows = ps.executeUpdate();
			System.out.println(rows + "row  inserted");
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		}
		
		
	}
	public void delete(String empid) throws ClassNotFoundException  {
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/orcl","scott","tiger");
			String query = "delete from add_faculty where empid=?";
			ps = conn.prepareStatement(query);
			ps.setString(1,empid);
			int res = ps.executeUpdate();
			System.out.println(res + " row deleted");
		} catch (SQLException e) {

			System.out.println(e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}

	}
	
	public void paperapprov(String p_id,String status) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/orcl","scott","tiger");
			String query = "update paper set status=? where p_id=?";
			ps = conn.prepareStatement(query);
			ps.setString(1, status);
			ps.setString(2,p_id);
			int res = ps.executeUpdate();
			System.out.println(res + " row updated");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		finally {
			try {
				conn.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}
		
	}
	public void leaveapprov(String empid,String status) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/orcl","scott","tiger");
			String query = "update leave set status=? where empid=?";
			ps = conn.prepareStatement(query);
			ps.setString(1, status);
			ps.setString(2,empid);
			int res = ps.executeUpdate();
			System.out.println(res + " row updated");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		finally {
			try {
				conn.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}
		
	}
	
	}
		
