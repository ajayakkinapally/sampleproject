package com.training.dao;

import com.training.bean.Leave;
import com.training.bean.Meeting;

public interface HodDao {
	public void create(Meeting m);

	public void create(Leave l);

}
