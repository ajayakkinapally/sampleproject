package com.training.dao;

import com.training.bean.Meeting;
import com.training.bean.UploadPaper;

public interface FacultyDao {
	public void create(Meeting m);

	public void create(UploadPaper up);


}
