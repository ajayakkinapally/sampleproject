package com.training.bean;

public class Leave {
	private String start_date;
	private String end_date;
	private String empid;
	private String status;
	public String getstart_date() {
		return start_date;
	}
	public void setstart_date(String start_date) {
		this.start_date= start_date;
	}
	public String getend_date() {
		return end_date;
	}
	public void setend_date(String end_date) {
		this.end_date = end_date;
	}
	public String getempid() {
		return empid;
	}
	public void setempid(String empid) {
		this.empid = empid;
	}
public String getstatus() {
		return status;
	}
	public void setstatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return String.format("Leave [start_date=%s, end_status=%s, empid=%s, status=%s]",
				start_date, end_date, empid, status);
	}
	
	

}
