package com.training.bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//import com.training.util.DBHandler;

//import com.training.util.DBHandler;

public class ManageDetails {

	private static int empid;

	public static void main(String args[]) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		System.out.println("Manage Details here");
		
		PreparedStatement ps = null;
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/orcl","scott","tiger");
			String query = "delete from student where empid=?";
			ps = conn.prepareStatement(query);
			ps.setInt(1,empid);
			int res = ps.executeUpdate();
			System.out.println(res + " row deleted");
		} catch (SQLException e) {

			System.out.println(e.getMessage());
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {

				System.out.println(e.getMessage());
			}
		}

	}

	}


