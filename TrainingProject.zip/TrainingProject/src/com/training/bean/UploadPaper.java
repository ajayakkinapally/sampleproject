package com.training.bean;

public class UploadPaper {

	private String p_id;
	private String subject;
	private String empid;
	private String status;
	private String branch;
	public String getp_id() {
		return p_id;
	}
	public void setp_id(String p_id) {
		this.p_id = p_id;
	}
	public String getsubject() {
		return subject;
	}
	public void setsubject(String subject) {
		this.subject = subject;
	}
	public String getempid() {
		return empid;
	}
	public void setempid(String empid) {
		this.empid = empid;
	}
	public String getstatus() {
		return status;
	}
	public void setstatus(String status) {
		this.status = status;
	}
	public String getbranch() {
		return branch;
	}
	public void setbranch(String branch) {
		this.branch = branch;
	}
	
}
