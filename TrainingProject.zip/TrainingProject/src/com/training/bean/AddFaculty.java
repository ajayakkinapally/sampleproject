package com.training.bean;

public class AddFaculty {
	private String empid;
	private String fname;
	private String lname;
	private String mail;
	private int contact;
	//private int sal;
	public String getempid() {
		return empid;
	}
	public void setempid(String empid) {
		this.empid = empid;
	}
	public String getfName() {
		return fname;
	}
	public void setfName(String fname) {
		this.fname = fname;
	}
	public String getlName() {
		return lname;
	}
	public void setlName(String lname) {
		this.lname = lname;
	}
	public String getmail() {
		return mail;
	}
	public void setmail(String mail) {
		this.mail = mail;
	}
	public int getcontact() {
		return contact;
	}
	public void setcontact(int contact) {
		this.contact = contact;
	}
/*	public int getsal() {
		return sal;
	}
	public void setsal(int sal) {
		this.sal = sal;
	}*/
	
	@Override
	public String toString() {
		return String.format("Student [empid=%s, name=%s, mail=%s, contact=%s]",
				empid, fname,lname, mail, contact);
	}
	

	

}
