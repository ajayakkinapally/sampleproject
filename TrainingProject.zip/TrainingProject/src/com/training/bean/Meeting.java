package com.training.bean;

public class Meeting {
	private int m_id;
	private String m_date;
	private String empid;
	public int getm_id() {
		return m_id;
	}
	public void setm_id(int m_id) {
		this.m_id = m_id;
	}
	public String getm_date() {
		return m_date;
	}
	public void setm_date(String m_date) {
		this.m_date = m_date;
	}
	public String getempid() {
		return empid;
	}
	public void setempid(String empid) {
		this.empid = empid;
	}
	
}
